./conv -i road_forest.jpeg -o road_forest.bmp -m 2
