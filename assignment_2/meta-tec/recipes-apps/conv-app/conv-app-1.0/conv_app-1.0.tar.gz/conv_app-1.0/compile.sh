rm conv
gcc -o conv conv.c -lm
